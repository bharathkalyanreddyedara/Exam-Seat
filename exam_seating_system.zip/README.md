# Exam Seating Arrangement System

A standalone web application built with pure HTML, CSS, and JavaScript that helps educational institutions manage exam seating arrangements and schedules.

## Features

- **User Authentication**: Secure login and registration system
- **Responsive Design**: Works on mobile, tablet, and desktop devices
- **Light/Dark Theme**: Toggle between light and dark modes
- **Student Dashboard**: View upcoming exams, seat assignments, and exam details
- **Exam Calendar**: View exams in a monthly calendar format
- **Seating Plan**: Visual representation of seat assignments for each exam
- **Print Functionality**: Generate printable admission tickets for exams

## Project Structure

```
/
├── index.html      # Main HTML structure
├── css/            # CSS styles
│   └── styles.css  # All styling and animations
├── js/             # JavaScript functionality
│   └── script.js   # All client-side functionality
└── data/           # Data storage
    ├── users.csv   # User account information
    ├── exams.csv   # Exam details
    └── student_seats.csv  # Seat assignments
```

## Data Storage

All data is stored in CSV files located in the `data` directory:

- **users.csv**: Stores user account information (id, username, password, role, email)
- **exams.csv**: Stores exam details (id, title, type, date, time, venue, status, color)
- **student_seats.csv**: Stores seat assignments (exam_id, student_id, seat_number)

## Default Accounts

For testing purposes, these default accounts are available:

- **Admin**: 
  - Username: admin
  - Password: admin123

- **Student**:
  - Username: student1
  - Password: student123
  - Username: student2
  - Password: student123

## Technologies Used

- **HTML5**: Page structure and content
- **CSS3**: Styling, animations, and responsive design
- **JavaScript (ES6+)**: Client-side functionality

## Running the Application

Simply open the `index.html` file in a modern web browser to use the application. No server or installation required.