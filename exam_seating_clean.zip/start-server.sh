#!/bin/bash
cd "$(dirname "$0")"
echo "Starting Node.js server on port 8080..."
node simple-server.js