# Exam Seating Arrangement System

This is a clean HTML, CSS, and JavaScript implementation of the Exam Seating Arrangement System. The application provides a comprehensive solution for managing exam seating arrangements and scheduling.

## Features

- User Authentication (Admin and Student roles)
- Dashboard with exam statistics
- Exam cards with filtering
- Detailed exam view
- Seating plan visualization
- Exam schedule calendar and timeline
- Interactive notifications

## Login Credentials

### Admin Login
- Username: admin
- Password: admin123

### Student Login
- Username: student1
- Password: student123

## File Structure

```
clean/
  ├── css/           # Styles
  │   └── styles.css
  ├── js/            # JavaScript 
  │   ├── script.js
  │   └── login-data.js
  ├── data/          # Data files (CSV)
  │   ├── exams.csv
  │   ├── student_seats.csv
  │   └── users.csv
  └── index.html     # Main HTML file
```

## Usage

To run the application, simply serve the files using a web server. Here are multiple options:

### Option 1: Using the included Node.js server
```
cd clean
./start-server.sh
```
This will start a custom Node.js server on port 8080 with proper MIME types and error handling.

### Option 2: Using Python HTTP Server
```
cd clean
python3 -m http.server 8000
```

### Option 3: Using Node.js http-server 
```
cd clean
npx http-server -p 8000
```

Then open your browser and navigate to the appropriate URL:
- Option 1: http://localhost:8080
- Option 2: http://localhost:8000 
- Option 3: http://localhost:8000

## Login Credentials

To test the application, use one of these login options:

### Admin Login
- Username: `admin`
- Password: `admin123`

### Student Login
- Username: `student1`
- Password: `student123`

## Development Notes

This project is built with:
- HTML5 for structure
- CSS3 for styling (including responsive design and light/dark themes)
- Vanilla JavaScript for interactivity
- Font Awesome for icons

No frameworks or libraries were used to keep the application lightweight and easy to understand.