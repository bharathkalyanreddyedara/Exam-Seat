/**
 * Login data for testing
 */
const loginData = {
  admin: {
    username: 'admin',
    password: 'admin123',
    role: 'admin'
  },
  student: {
    username: 'student1',
    password: 'student123',
    role: 'student'
  }
};